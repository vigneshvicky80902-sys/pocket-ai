"""PocketSmart AI application package."""
